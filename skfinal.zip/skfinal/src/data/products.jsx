export const products = [
  {
    id: 1,
    name: "King-Size Cots",
    category: "Cot & Mattresses",
    price: 29999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/KingSizeCots.png"),
    description: "Modern maximum space and comfort.",
    material: "Wood",
    inStock: true,
  },
  {
    id: 2,
    name: "Queen-Size Cots",
    category: "Cot & Mattresses",
    price: 29999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/Queen-SizeCots.png"),
    description: "Wood Queen Box Bed",
    material: "Wood",
    inStock: true,
  },
  {
    id: 3,
    name: "Wooden Double Bed Cots",
    category: "Cot & Mattresses",
    price: 28999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/Double Bed Cots.png"),
    description: "Ideal for couples or those who prefer more space.",
    material: "Wood",
    inStock: false,
  },
  {
    id: 4,
    name: "Metal King-Size Cots",
    category: "Cot & Mattresses",
    price: 27999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/King-Sizemetal.png"),
    description: "Durable and sturdy, perfect for long-term use.",
    material: "Metal",
    inStock: true,
  },
  {
    id: 5,
    name: "Single Cots",
    category: "Cot & Mattresses",
    price: 25999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/Single Cots.png"),
    description: "Best for single sleepers or guest rooms",
    material: "Metal",
    inStock: true,
  },
  {
    id: 6,
    name: "Memory Foam Mattresses",
    category: "Cot & Mattresses",
    price: 27999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/MemoryMattresses.png"),
    description:
      "Conforms to your body providing excellent support and comfort",
    material: "Metal",
    inStock: true,
  },
  {
    id: 7,
    name: "Pocket Spring Mattresses",
    category: "Cot & Mattresses",
    price: 26999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/Pocket Spring Mattresses.png"),
    description: "Sleepwell Ortho PRO Spring wrapped",
    material: "Metal",
    inStock: true,
  },
  {
    id: 8,
    name: "Corner Wardrobes",
    category: "Wardrobe",
    price: 24999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/CornerWardrobes.png"),
    description: "3 Door with Locker and Star Design Mirror",
    material: "Metal",
    inStock: true,
  },
  {
    id: 9,
    name: "Pretty Wardrobe",
    category: "Wardrobe",
    price: 25999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/Pretty Wardrobe.png"),
    description: "3 Door with Mirror for Dressing spaces",
    material: "Wood",
    inStock: true,
  },
  {
    id: 10,
    name: "Sliding Wardrobes",
    category: "Wardrobe",
    price: 23999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/SlidingWardrobes.png"),
    description:
      "Wood 2 Door slide horizontally drawer and multiple shelves for organizing clothes and storage Wardrobe",
    material: "Wood",
    inStock: true,
  },
  {
    id: 11,
    name: "Two-Seater sofa",
    category: "Sofas",
    price: 19999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/TwoSetsofa.png"),
    description: "Perfect for small spaces or cozy seating.",
    material: "Fabric",
    inStock: true,
  },
  {
    id: 12,
    name: "One-Seater sofa",
    category: "Sofas",
    price: 20999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/One-Seatersofa.png"),
    description: "Contemporary 3-seater sofa with premium fabric upholstery",
    material: "Fabric",
    inStock: true,
  },
  {
    id: 13,
    name: "Three-Seater",
    category: "Sofas",
    price: 22999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/Three-Seatersofa1.jpeg"),
    description:
      "Modern sofa with premium Gray fabric upholstery, perfect for adding elegance to your living room.",
    material: "Fabric",
    inStock: true,
  },
  {
    id: 14,
    name: "Three-Seater",
    category: "Sofas",
    price: 24999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/Three-Seatersofa.png"),
    description:
      "Luxurious teal blue velvet sofa, providing exceptional comfort and style.",
    material: "Fabric",
    inStock: true,
  },
  {
    id: 15,
    name: "Woodden Sofa",
    category: "Sofas",
    price: 23999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/Woodden-Sofa.png"),
    description:
      "Versatile Woodden sofa, perfect for matching various decor styles.",
    material: "Fabric",
    inStock: true,
  },
  {
    id: 16,
    name: "Three-Seater",
    category: "Sofas",
    price: 21999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/Three-Seatersofa3.png"),
    description:
      "Elegant pine green velvet sofa, combining classic design with modern comfort.",
    material: "Fabric",
    inStock: true,
  },
  {
    id: 17,
    name: "Hilton Wooden Dining Table",
    category: "Dining Table",
    price: 25999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/DiningTable1.png"),
    description:
      "A versatile dining set that includes a spacious wooden table, six chairs making it perfect for larger gatherings.",
    material: "Wood",
    inStock: true,
  },
  {
    id: 18,
    name: "Malaysian Wooden Dining",
    category: "Dining Table",
    price: 26999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/FourDiningTable.png"),
    description:
      "Elegant four comfortable chairs, making it ideal for small families, perfect for a cozy dining experience",
    material: "Wood",
    inStock: true,
  },
  {
    id: 19,
    name: "Terence Wooden Dining Set",
    category: "Dining Table",
    price: 24999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/RoundDining3.png"),
    description:
      "Its round shape encourages conversation and is perfect for intimate dining experiences.",
    material: "Wood",
    inStock: true,
  },
  {
    id: 20,
    name: "Royaloak Hilton Wooden",
    category: "Dining Table",
    price: 25999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/RoundDining4.png"),
    description:
      "Crafted from premium wood, this 6-seater dining set offers seating and a timeless. Its ideal for family dinners and gatherings.",
    material: "Wood",
    inStock: true,
  },
  {
    id: 21,
    name: "Office Chair",
    category: "Wooden Chairs",
    price: 14999, // Adjusted to fit within ₹30,000
    image: require("../assets/products/WooddenChair1.png"),
    description: "Ergonomic office chair with lumbar support",
    material: "Mesh",
    inStock: true,
  },
];
