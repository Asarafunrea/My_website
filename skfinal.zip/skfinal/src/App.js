import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./com/Navbar";
import Footer from "./com/Footer";
import SofaProcess from "./com/SofaProcess";
import Categories from "./com/Categories";
import Store from "./com/Store";
import FAQ from "./com/FAQ";
import ProductPage from "./com/ProductPage";
import ManufactureStore from "./com/ManufactureStore";
import { AboutUs } from "./com/about";
import ContactSection from "./com/ContactSection";
import LivingRoomSection from "./com/LivingRoomSection";
import Dealofmonth from "./com/Dealofmonth";
import NewHome from "./com/NewHome";

function App() {

  return (
    <Router>
      <div>
        <Navbar />
        <Routes>
          {/* Home Page Route */}
          <Route
            path="/"
            element={
              <>
                <NewHome />
                <Categories />
                <LivingRoomSection />
                <Dealofmonth />
                <SofaProcess />
                <Store />
              </>
            }
          />

          {/* Products Page Route */}
          <Route
            path="/products"
            element={
              <>
              <ProductPage/>
              </>
            }
          />
          {/* About Us Page Route */}
          <Route
            path="/about"
            element={
              <>
                <AboutUs />
                <ManufactureStore />
                <FAQ />
              </>
            }
          />
          {/* Contact Page Route */}
          <Route path="/contact" element={<ContactSection />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
