import React from "react";

export default function FAQ() {
  const faqItems = [
    {
      question: "How do I place an order?",
      answer:
        "Click the WhatsApp icon next to the product to place your order, and our team will assist you promptly.",
    },
    {
      question: "What types of furniture do you offer?",
      answer:
        "We offer a wide range of furniture including living room sets, bedroom furniture, dining sets, office furniture, outdoor furniture, and custom pieces. All our pieces are available in various styles, from modern to traditional.",
    },
    {
      question: "Do you offer customization options?",
      answer:
        "Yes, we offer customization options for most of our furniture pieces. You can choose from different fabrics, colors, sizes, and finishes to match your specific needs and preferences.",
    },
    {
      question: "What is your warranty policy?",
      answer:
        "Our furniture comes with a standard 1-year warranty against manufacturing defects. Extended warranty options are available for purchase. The warranty covers structural integrity and craftsmanship issues.",
    },
  ];

  return (
    <section className="py-5">
      <div className="container">
        <h2
          style={{
            fontSize:"1.5rem", // Dynamically changing font size
            color: "#0E6B66",
            fontWeight: 600,
            marginBottom: "1rem",
            lineHeight: 1.3,
            textShadow: "0 2px 4px rgba(0, 0, 0, 0.1)", // Slight shadow
          }}
          className="text-center mb-5"
        >
          Frequently Asked Questions
        </h2>
        <div className="accordion" id="faqAccordion">
          {faqItems.map((item, index) => (
            <div className="accordion-item mb-3" key={index}>
              <h2 className="accordion-header" id={`heading${index}`}>
                <button
                  className="accordion-button"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target={`#collapse${index}`}
                  aria-expanded="true"
                  aria-controls={`collapse${index}`}
                  style={{
                    color: "#000", // Black text color
                    backgroundColor: "transparent", // Transparent background
                    border: "none", // No borders
                    boxShadow: "none", // No box-shadow
                  }}
                >
                  <span className="fw-semibold">{item.question}</span>
                </button>
              </h2>
              <div
                id={`collapse${index}`}
                className="accordion-collapse collapse"
                aria-labelledby={`heading${index}`}
                data-bs-parent="#faqAccordion"
              >
                <div className="accordion-body">{item.answer}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
