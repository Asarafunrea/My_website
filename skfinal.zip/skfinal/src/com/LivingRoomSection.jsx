import React from "react";
import { useNavigate } from "react-router-dom";
import ssofa from "../assets/Leather.png";
import setsofa from "../assets/sofas.png";
import Tv from "../assets/tv.png";
import singletable from "../assets/Single_table.jpg";
import coffee from "../assets/coffee.jpg";

const LivingRoomSection = () => {
  const navigate = useNavigate();

  return (
    <section className="py-5" style={{ backgroundColor: "#fafaf2" }}>
      <div className="container">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h2
            style={{
              fontSize: "1.5rem",
              color: "#0E6B66",
              fontWeight: 600,
              marginBottom: "1rem",
              lineHeight: 1.3,
              textShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
            }}
          >
            Featured Products
          </h2>
          <button
            className="btn btn-outline-secondary"
            onClick={() => navigate("/products")}
          >
            See All
          </button>
        </div>

        <div className="row g-4">
          {/* Featured Item */}
          <div className="col-12 col-lg-6 mb-4 position-relative">
            <div style={{ position: "relative" }}>
              <img
                src={ssofa}
                alt="Comfort Recliner"
                className="card-img-top"
                style={{ height: "500px", objectFit: "contain" }}
              />
              <h3
                style={{

                  position: "absolute",
                  top: "10px",
                  left: "10px",
                  color: "#fff",
                  backgroundColor: "rgba(26, 26, 26, 0.6)",
                  padding: "5px 10px",
                  borderRadius: "5px",
                  fontWeight: "bold",
                  fontSize: "1.25rem",
                }}
              >
              </h3>
            </div>
          </div>

          {/* Grid Items */}
          <div className="col-12 col-lg-6">
            <div className="row row-cols-2 g-3">
              {/* Modern Sofa */}
              <div className="col">
                <div className="h-100">
                  <img
                    src={setsofa}
                    alt="Modern Sofa"
                    className="card-img-top"
                    style={{ height: "200px", objectFit: "cover" }}
                  />
                  <h6
                    className="card-title text-center mt-2"
                    style={{ fontWeight: "bold" }}
                  >
                    Modern Sofa
                  </h6>
                </div>
              </div>

              {/* TV Unit */}
              <div className="col">
                <div className="h-100">
                  <img
                    src={Tv}
                    alt="Entertainment Unit"
                    className="card-img-top"
                    style={{ height: "200px", objectFit: "cover" }}
                  />
                  <h6
                    className="card-title text-center mt-2"
                    style={{ fontWeight: "bold" }}
                  >
                    TV Unit
                  </h6>
                </div>
              </div>

              {/* Side Table */}
              <div className="col">
                <div className="h-100">
                  <img
                    src={singletable}
                    alt="Side Table"
                    className="card-img-top"
                    style={{ height: "200px", objectFit: "cover" }}
                  />
                  <h6
                    className="card-title text-center mt-2"
                    style={{ fontWeight: "bold" }}
                  >
                    Side Table
                  </h6>
                </div>
              </div>

              {/* Coffee Table */}
              <div className="col">
                <div className="h-100">
                  <img
                    src={coffee}
                    alt="Coffee Table"
                    className="card-img-top"
                    style={{ height: "200px", objectFit: "cover" }}
                  />
                  <h6
                    className="card-title text-center mt-2"
                    style={{ fontWeight: "bold" }}
                  >
                    Coffee Table
                  </h6>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LivingRoomSection;
