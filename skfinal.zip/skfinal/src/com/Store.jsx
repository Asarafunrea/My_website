

// export default Stores;
import React, { useState, useEffect } from "react";

const StoreLocation = () => {
  const [fontSize, setFontSize] = useState("1rem");

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth <= 768) {
        setFontSize("1rem"); // Smaller font size on mobile
      } else {
        setFontSize("1.5rem"); // Larger font size on bigger screens
      }
    };

    window.addEventListener("resize", handleResize);
    
    handleResize();

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <div className="container my-5">
      <h1
        style={{
          fontSize: fontSize, // Dynamically changing font size
          color: "#0E6B66",
          fontWeight: 600,
          marginBottom: "1rem",
          textTransform: "uppercase",
          letterSpacing: "2px",
          lineHeight: 1.3,
          textShadow: "0 2px 4px rgba(0, 0, 0, 0.1)", // Slight shadow
        }}
      >
        Our Store Location
      </h1>
      {/* Your content goes here */}
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3911.5445267865803!2d77.86582809120664!3d11.367941814862009!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba961fd4b4ab86b%3A0x20e9c6fbd85228a0!2sSri%20Krishna%20furniture!5e0!3m2!1sen!2sin!4v1732381877318!5m2!1sen!2sin"
        width="100%"
        height="450"
        style={{ border: "0" }}
        allowFullScreen // Correct way to pass boolean attributes in JSX
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
      />
    </div>
  );
};

export default StoreLocation;
