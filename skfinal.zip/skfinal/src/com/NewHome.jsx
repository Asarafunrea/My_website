import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "../styles/newhome.css";
import newarr from "../assets/test.png"; 
import sofacum from "../assets/10.gif"

const Homepage = () => {
  return (
    <div className="container-fluid">
      <div className="row">
        {/* Left Column: Carousel */}
        <div className="col-md-8 p-0">
          <div
            id="imageCarousel"
            className="carousel slide"
            data-bs-ride="carousel"
          >
            <div className="carousel-inner">
              <div className="carousel-item active">
                <img
                  src="https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&q=80"
                  className="d-block w-100"
                  alt="Wooden Sofa"
                />
              </div>
              <div className="carousel-item">
                <img
                  src="https://images.unsplash.com/photo-1550226891-ef816aed4a98?auto=format&fit=crop&q=80"
                  className="d-block w-100"
                  alt="New Arrivals"
                />
              </div>
              <div className="carousel-item">
                <img
                  src="https://images.unsplash.com/photo-1550226891-ef816aed4a98?auto=format&fit=crop&q=80"
                  className="d-block w-100"
                  alt="Sofa Cum Bed"
                />
              </div>
            </div>
            <button
              className="carousel-control-prev"
              type="button"
              data-bs-target="#imageCarousel"
              data-bs-slide="prev"
            >
              <span
                className="carousel-control-prev-icon"
                aria-hidden="true"
              ></span>
              <span className="visually-hidden">Previous</span>
            </button>
            <button
              className="carousel-control-next"
              type="button"
              data-bs-target="#imageCarousel"
              data-bs-slide="next"
            >
              <span
                className="carousel-control-next-icon"
                aria-hidden="true"
              ></span>
              <span className="visually-hidden">Next</span>
            </button>
          </div>
        </div>

        {/* Right Column: Stacked Images */}
        <div className="col-md-4 d-flex flex-column gap-1">
          <img src={newarr} alt="Stacked Image 1" className="mb-3 h-50" />
          <img src={sofacum} alt="Stacked Image 2" className="h-50" />
        </div>
      </div>
    </div>
  );
};

export default Homepage;
