// export default Stores;
import React, { useState, useEffect } from "react";

const ManufactureStore = () => {
  const [fontSize, setFontSize] = useState("1rem");

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth <= 768) {
        setFontSize("1rem"); // Smaller font size on mobile
      } else {
        setFontSize("1.5rem"); // Larger font size on bigger screens
      }
    };

    window.addEventListener("resize", handleResize);

    // Call once on initial render
    handleResize();

    // Cleanup on component unmount
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <div className="container my-5">
      <h1
        style={{
          fontSize:"1.2rem",
          color: "#0E6B66",
          fontWeight: 600,
          marginBottom: "1rem",
          textTransform: "uppercase",
          letterSpacing: "2px",
          lineHeight: 1.3,
          textShadow: "0 2px 4px rgba(0, 0, 0, 0.1)", // Slight shadow
        }}
      >
        Our Manufacture Store Location
      </h1>
      {/* Your content goes here */}
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13156.273066313106!2d77.8597635850183!3d11.37967598131523!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba96133a132ef9f%3A0x4c53ebe43ec21319!2sSri%20Krishna%20sofa%20company!5e0!3m2!1sen!2sin!4v1732814775058!5m2!1sen!2sin"
        width="100%"
        height="450"
        style={{ border: "0" }}
        allowFullScreen // Correct way to pass boolean attributes in JSX
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
      />
    </div>
  );
};

export default ManufactureStore;
