import React from "react";
import { useNavigate } from "react-router-dom";
import con from "../assets/con.png";
import factory from "../assets/factory.jpg";

export function AboutUs() {
  const navigate = useNavigate(); // Initialize navigate

  return (
    <div className="my-4">
      {/* Hero Section */}
      <section className="bg-white py-8 sm:py-12 md:py-16 px-4 sm:px-6 lg:px-8">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-12 col-md-6">
              <h1
                className="text-3xl sm:text-4xl md:text-5xl font-bold text-[#0E6B66] leading-tight"
                style={{
                  fontSize: "1.5rem",
                  color: "#0E6B66",
                  fontWeight: 600,
                  marginBottom: "1rem",
                  lineHeight: 1.3,
                  textShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                }}
              >
                Who Are We?
              </h1>
              <p className="text-gray-600 text-base sm:text-lg">
                Srikrishna Furniture is a leading manufacturer of high-quality
                sofas and furniture in the region. We take pride in our
                craftsmanship and offer excellent warranty and service for all
                our products.
              </p>
              <button
                style={{
                  backgroundColor: "#CDCDCD",
                  fontWeight: "bold",
                  padding: "0.5rem 1rem",
                  borderRadius: "0.375rem",
                  transition: "all 0.3s ease-in-out",
                  border: "none",
                }}
                onMouseOver={(e) =>
                  (e.target.style.backgroundColor = "#CCDEF5")
                }
                onMouseOut={(e) => (e.target.style.backgroundColor = "#CDCDCD")}
                onClick={() => navigate("/contact")} // Use navigate function here
              >
                Contact Us
              </button>
            </div>
            <div className="col-12 col-md-6 mt-4 mt-md-0">
              <img
                src={con}
                alt="Modern furniture workshop"
                className="img-fluid rounded-lg shadow-lg"
                style={{
                  maxHeight: "350px",
                  objectFit: "cover",
                  width: "90%",
                }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="bg-gray-100 py-8 sm:py-12 md:py-16">
        <div className="container">
          <div className="text-center mb-8 sm:mb-12">
            <h2
              className="text-center mt-5"
              style={{
                fontSize: "1.5rem",
                color: "#0E6B66",
                fontWeight: 600,
                marginBottom: "1rem",
                lineHeight: 1.3,
                textShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
              }}
            >
              More About Us
            </h2>
          </div>
          <div className="row align-items-center">
            <div className="col-12 col-md-6 order-md-1">
              <img
                src={factory} // Correct the placeholder
                alt="Furniture Manufacturing"
                className="img-fluid rounded-lg shadow-lg"
                style={{
                  maxHeight: "300px",
                  objectFit: "cover",
                  width: "100%",
                }}
              />
            </div>
            <div className="col-12 col-md-6 order-md-2 mt-4 mt-md-0">
              <p className="text-gray-700 text-base sm:text-lg">
                Srikrishna Furniture has been manufacturing high-quality sofas
                and furniture since its inception. We focus on using premium
                materials to ensure durability and comfort in all our products.
              </p>
              <p className="text-gray-700 text-base sm:text-lg">
                Our designs blend contemporary styles with traditional comfort,
                catering to the diverse needs and tastes of our customers. We
                take pride in using top-grade materials in all our furniture
                pieces.
              </p>
              <p className="text-gray-700 text-base sm:text-lg">
                At Srikrishna Furniture, we are committed to innovation and
                creativity in furniture design. We strive to deliver luxurious,
                comfortable, and beautiful furniture that perfectly matches our
                clients' requirements. Our excellent warranty and after-sales
                service ensure customer satisfaction long after the purchase.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
