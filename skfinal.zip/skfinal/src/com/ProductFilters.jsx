import React, { useState } from "react";
import "../styles/ProductFilters.css";
import { FaSlidersH } from "react-icons/fa";
import { MdClose } from "react-icons/md";

function ProductFilters({
  selectedCategories,
  selectedMaterials,
  priceRange,
  inStockOnly,
  onCategoryChange,
  onMaterialChange,
  onPriceRangeChange,
  onInStockChange,
  onClearFilters,
}) {
  const [isFiltersVisible, setIsFiltersVisible] = useState(false);

  const toggleFilters = () => {
    setIsFiltersVisible(!isFiltersVisible);
  };

  const categories = [
    "Cot & Mattresses",
    "Wardrobe",
    "Dining Table",
    "Sofas",
    "Wooden Chairs",
  ];
  const materials = ["Wood", "Metal", "Fabric", "Mesh"];

  return (
    <div>
      {/* Toggle Button for smaller screens */}
      <button className="filter-button" onClick={toggleFilters}>
        <FaSlidersH className="filters-icon" />
        Filters
      </button>

      {/* Filters Modal */}
      <div className={`filters ${isFiltersVisible ? "show-filters" : ""}`}>
        <div className="filters-header">
          <h5>Filters</h5>
          <button className="close-button" onClick={toggleFilters}>
            <MdClose />
          </button>
        </div>

        {/* Category Filter */}
        <div className="filter-group">
          <label>Category</label>
          {categories.map((category) => (
            <div key={category} className="form-check">
              <input
                type="checkbox"
                checked={selectedCategories.includes(category)}
                onChange={() => onCategoryChange(category)}
                className="form-check-input"
              />
              <label className="form-check-label">{category}</label>
            </div>
          ))}
        </div>

        {/* Material Filter */}
        <div className="filter-group">
          <label>Material</label>
          {materials.map((material) => (
            <div key={material} className="form-check">
              <input
                type="checkbox"
                checked={selectedMaterials.includes(material)}
                onChange={() => onMaterialChange(material)}
                className="form-check-input"
              />
              <label className="form-check-label">{material}</label>
            </div>
          ))}
        </div>

        {/* Price Range Filter */}
        <div className="filter-group">
          <label>Max Price: ₹{priceRange.toLocaleString()}</label>
          <input
            type="range"
            min="0"
            max="30000"
            step="2000"
            value={priceRange}
            onChange={(e) => onPriceRangeChange(Number(e.target.value))}
            className="form-range"
          />
        </div>

        {/* In-Stock Only Filter */}
        <div className="filter-group">
          <input
            type="checkbox"
            checked={inStockOnly}
            onChange={(e) => onInStockChange(e.target.checked)}
            className="form-check-input"
          />
          <label>In Stock Only</label>
        </div>

        {/* Clear Filters */}
        <button className="clear-button" onClick={onClearFilters}>
          Clear Filters
        </button>
      </div>
    </div>
  );
}

export default ProductFilters;
