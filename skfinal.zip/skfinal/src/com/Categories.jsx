import React from "react";
import { useNavigate } from "react-router-dom"; // Import for navigation
import cotImage from "../assets/bedroom.png";
import wardrobeImage from "../assets/wardrobe.png";
import sofaImage from "../assets/sofa.png";
import diningTableImage from "../assets/diningTable.png";
import woodenChairsImage from "../assets/chair.png";
import sales from "../assets/sales.png";
import "../styles/categories.css"; // Import the external CSS for styling

const Categories = () => {
  const navigate = useNavigate();

  const images = [
    cotImage,
    wardrobeImage,
    sofaImage,
    diningTableImage,
    woodenChairsImage,
    sales,
  ];

  const labels = [
    "Cot & Mattresses",
    "Wardrobe",
    "Sofas",
    "Dining Table",
    "Wooden Chairs",
    "Sales",
  ];

  const handleCategoryClick = (category) => {
    navigate(`/products`, { state: { category } }); // Navigate to ProductPage with state
  };

  return (
    <div className="container my-5">
      <section>
        <h2 className="section-title">Our Collections</h2>
        <hr className="section-divider" />
        <div className="row row-cols-2 row-cols-sm-3 row-cols-md-6 g-4">
          {labels.map((label, index) => (
            <div
              key={index}
              className="col text-center"
              onClick={() => handleCategoryClick(label)} // Handle category click
              style={{ cursor: "pointer" }} // Add pointer cursor
            >
              <div className="circle-image-container">
                <img
                  src={images[index % images.length]} // Cycle through images for demo
                  alt={label}
                  className="img-fluid rounded-circle collection-image"
                />
              </div>
              <p className="collection-text">{label}</p>
            </div>
          ))}
        </div>
      </section>
      <hr className="section-divider" />
    </div>
  );
};

export default Categories;
