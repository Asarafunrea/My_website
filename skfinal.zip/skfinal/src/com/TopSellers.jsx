import React, { useRef } from "react";
import { Link } from "react-router-dom";
import { Heart } from "react-feather";
import { FiChevronLeft, FiChevronRight } from "react-icons/fi";
import sofaImage from "../assets/ssofa.jpg";
import tableImage from "../assets/Room.jpg";
import bedImage from "../assets/pic4.jpg";
import chairImage from "../assets/pic2.jpg";
import cabinetImage from "../assets/study.jpg";

const products = [
  {
    id: 1,
    name: "Modern Luxury Sofa",
    image: sofaImage,
    originalPrice: 29999,
    discountedPrice: 24999,
    discount: 17,
    available: true,
  },
  {
    id: 2,
    name: "Elegant Wooden Dining Table",
    image: tableImage,
    originalPrice: 35000,
    discountedPrice: 29999,
    discount: 14,
    available: true,
    isNew: true,
  },
  {
    id: 3,
    name: "Queen Size Hydraulic Bed",
    image: bedImage,
    originalPrice: 40000,
    discountedPrice: 34999,
    discount: 13,
    available: true,
  },
  {
    id: 4,
    name: "Comfortable Recliner Chair",
    image: chairImage,
    originalPrice: 19999,
    discountedPrice: 17999,
    discount: 10,
    available: true,
    isNew: true,
  },
  {
    id: 5,
    name: "Spacious Storage Cabinet",
    image: cabinetImage,
    originalPrice: 25000,
    discountedPrice: 22999,
    discount: 8,
    available: true,
  },
];

const TopSellers = () => {
  const scrollContainerRef = useRef(null);

  const scroll = (direction) => {
    if (scrollContainerRef.current) {
      const scrollAmount = direction === "left" ? -320 : 320;
      scrollContainerRef.current.scrollBy({
        left: scrollAmount,
        behavior: "smooth",
      });
    }
  };

  return (
    <section className="py-5" style={{ backgroundColor: "#F0FDFE" }}>
      <div className="container">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h2
              style={{
                fontSize: "1.5rem",
                color: "#0E6B66",
                fontWeight: 600,
                marginBottom: "1rem",
                lineHeight: 1.3,
                textShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
              }}
              className="h1 mb-2"
            >
              Top Sellers
            </h2>
            <p className="text-muted">
              Discover Our Finest Furniture Collection
            </p>
          </div>
          <Link to="/products" className="btn btn-outline-secondary">
            EXPLORE COLLECTION
            <i className="bi bi-arrow-right ms-2"></i>
          </Link>
        </div>

        {/* Product Carousel */}
        <div className="position-relative">
          <div
            ref={scrollContainerRef}
            className="d-flex overflow-auto gap-4 pb-4"
            style={{
              scrollSnapType: "x mandatory",
              scrollbarWidth: "none",
              msOverflowStyle: "none",
            }}
          >
            {products.map((product) => (
              <div
                key={product.id}
                className="card flex-shrink-0"
                style={{ width: "300px", scrollSnapAlign: "start" }}
              >
                <div className="position-relative">
                  <img
                    src={product.image}
                    className="card-img-top"
                    alt={product.name}
                    style={{ height: "200px", objectFit: "cover" }}
                  />
                  <button className="btn position-absolute top-0 end-0 m-2 bg-white rounded-circle p-2 shadow">
                    <Heart size={20} />
                  </button>
                  {product.isNew && (
                    <span className="position-absolute top-0 start-0 m-2 badge bg-danger shadow-sm">
                      New
                    </span>
                  )}
                </div>
                <div className="card-body">
                  <h5 className="card-title text-truncate">{product.name}</h5>
                  <div className="d-flex align-items-center gap-2 mb-2">
                    <span className="h5 mb-0">
                      ₹{product.discountedPrice.toLocaleString()}
                    </span>
                    <span className="text-decoration-line-through text-muted">
                      ₹{product.originalPrice.toLocaleString()}
                    </span>
                    <span className="text-danger">
                      ({product.discount}% Off)
                    </span>
                  </div>
                  {product.available && (
                    <span className="badge bg-success bg-opacity-10 text-success">
                      Available Online
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Navigation Buttons */}
          <button
            className="btn btn-secondary position-absolute start-0 top-50 translate-middle-y"
            onClick={() => scroll("left")}
            style={{ zIndex: 1 }}
          >
            <FiChevronLeft />
            <span className="visually-hidden">Previous</span>
          </button>
          <button
            className="btn btn-secondary position-absolute end-0 top-50 translate-middle-y"
            onClick={() => scroll("right")}
            style={{ zIndex: 1 }}
          >
            <FiChevronRight />
            <span className="visually-hidden">Next</span>
          </button>
        </div>
      </div>
    </section>
  );
};

export default TopSellers;
