import React from "react";
import study from "../assets/deal.jpg";

const Dealofmonth = () => {
  return (
    <section className="py-5">
      <div className="container">
        <div className="row align-items-center">
          {/* Text Content */}
          <div
            className="col-lg-6 order-2 order-lg-1 mb-4 mb-lg-0 text-center text-lg-start"
            style={{ padding: "1rem" }}
          >
            <h2
              className="mb-3"
              style={{
                fontFamily: "Abhaya Libre",
                fontSize: "2rem",
                fontWeight: 600,
                marginBottom: "1rem",
              }}
            >
              Deal of the month
            </h2>
            <p className="text-muted mb-4" style={{ fontSize: "1rem" }}>
              You'll love the exclusive offers, promotions, and unique gift
              ideas. Start shopping with Good Furniture.
            </p>
          </div>

          {/* Image Content */}
          <div className="col-lg-6 order-1 order-lg-2 position-relative">
            <div
              className="position-absolute top-0 end-0 bg-danger text-white px-3 py-2 m-3 rounded"
              style={{ fontSize: "0.9rem", zIndex: 2 }}
            >
              FLAT 25% OFF
            </div>
            <img
              src={study}
              alt="Deal of the month"
              className="img-fluid rounded shadow-sm w-100"
              style={{
                maxHeight: "400px",
                objectFit: "cover",
              }}
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Dealofmonth;
