import React, { useState, useEffect } from "react";
import { FaWhatsapp } from "react-icons/fa";
import { IoMenu, IoClose } from "react-icons/io5";
import { Phone } from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import logo from "../assets/logo.png";
import "../styles/nav.css";

const Nav = () => {
  const [isActive, setIsActive] = useState(false);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [isNavVisible, setIsNavVisible] = useState(true);
  const [activeLink, setActiveLink] = useState("");
  const location = useLocation();

  const handleToggle = () => {
    setIsActive(!isActive);
  };

  const handleNavItemClick = (link) => {
    setActiveLink(link);
    setIsActive(false); // Close menu on item click
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > lastScrollY && window.scrollY > 100) {
        setIsNavVisible(false);
      } else {
        setIsNavVisible(true);
      }

      setLastScrollY(window.scrollY);
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, [lastScrollY]);

  return (
    <nav
      className="navbar navbar-expand-lg fixed-top"
      style={{
        top: isNavVisible ? "0" : "-80px",
        transition: "top 0.3s ease",
        backgroundColor: "white",
      }}
    >
      <div className="container">
        <Link
          className={`nav-link ${activeLink === "home" ? "active" : ""}`}
          to="/"
          onClick={() => handleNavItemClick("home")}
        >
          <img src={logo} alt="Furniture Co." className="logo" />
          <span className="brand-name ms-2">SRI KRISHNA FURNITURE</span>
          {activeLink === "home" && <div className="underline"></div>}
        </Link>

        <button
          className="navbar-toggler"
          type="button"
          onClick={handleToggle}
          aria-controls="navbarNav"
          aria-expanded={isActive ? "true" : "false"}
          aria-label="Toggle navigation"
        >
          {isActive ? (
            <IoClose className="text-dark" size={30} />
          ) : (
            <IoMenu className="text-dark" size={30} />
          )}
        </button>

        {/* Sidebar Menu (Hamburger Menu) */}
        <div className={`navbar-menu ${isActive ? "open" : ""}`} id="navbarNav">
          {/* Logo and Name for Mobile */}
          <div className="logo-container">
            <img src={logo} alt="Furniture Co." className="logo" />
            <span className="brand-name ms-2">SRI KRISHNA FURNITURE</span>
          </div>

          {/* Navbar Links */}
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link
                className={`nav-link ${activeLink === "home" ? "active" : ""}`}
                to="/"
                onClick={() => handleNavItemClick("home")}
              >
                Home
                {activeLink === "home" && <div className="underline"></div>}
              </Link>
            </li>
            <li className="nav-item">
              <Link
                className={`nav-link ${
                  activeLink === "products" ? "active" : ""
                }`}
                to="/products"
                onClick={() => handleNavItemClick("products")}
              >
                Products
                {activeLink === "products" && <div className="underline"></div>}
              </Link>
            </li>
            <li className="nav-item">
              <Link
                className={`nav-link ${activeLink === "about" ? "active" : ""}`}
                to="/about"
                onClick={() => handleNavItemClick("about")}
              >
                About Us
                {activeLink === "about" && <div className="underline"></div>}
              </Link>
            </li>
            <li className="nav-item">
              <Link
                className={`nav-link ${
                  activeLink === "contact" ? "active" : ""
                }`}
                to="/contact"
                onClick={() => handleNavItemClick("contact")}
              >
                Contact
                {activeLink === "contact" && <div className="underline"></div>}
              </Link>
            </li>
          </ul>
        </div>

        {/* Call Us Button */}
        <div className="d-none d-lg-flex align-items-center">
          <a
            href="tel:+916385894422"
            className="custom-link d-flex align-items-center gap-2"
          >
            <Phone className="custom-icon h-4 w-4 mr-2" />
            Call Us
          </a>
        </div>
      </div>
      <a
        href="https://api.whatsapp.com/send?phone=916385894422&text=Hello%2C%20I%20am%20interested%20in%20purchasing%20furniture%20from%20your%20store.%20Could%20you%20please%20provide%20more%20details%3F"
        target="_blank"
        rel="noopener noreferrer"
        className="whatsapp-btn"
      >
        <FaWhatsapp size={28} color="white" />
      </a>
    </nav>
  );
};

export default Nav;
