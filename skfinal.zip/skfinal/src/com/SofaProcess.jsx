import React, { useState, useEffect, useMemo } from "react";
import { FaStore, FaUsers, FaTruck, FaClock, FaTags } from "react-icons/fa";
import { useInView } from "react-intersection-observer";
import "../styles/sofaprocess.css";


const AboutSection = () => {
  const stats = useMemo(
    () => [
      {
        icon: <FaStore className="text-danger" size={32} />,
        number: 9,
        title: "Experience",
        subtitle: "Stores",
      },
      {
        icon: <FaUsers className="text-danger" size={32} />,
        number: 50, // For "5Lakh+", will be formatted during display
        title: "Satisfied",
        subtitle: "Customers",
      },
      // {
      //   icon: <FaTruck className="text-danger" size={32} />,
      //   number: 350,
      //   title: "Delivery",
      //   subtitle: "Centers",
      // },
      {
        icon: <FaClock className="text-danger" size={32} />,
        number: "24",
        title: "Months",
        subtitle: "Warranty",
      },
      {
        icon: <FaTags className="text-danger" size={32} />,
        number: "",
        title: "Lowest Price",
        subtitle: "Guarantee",
      },
    ],
    []
  );

  const [counters, setCounters] = useState([0, 0, 0]); // For "9+", "5Lakh+", and "350+" stats
  const { ref, inView } = useInView({ triggerOnce: true, threshold: 0.5 });

  useEffect(() => {
    if (inView) {
      const durations = [1000, 2000, 1500]; // Animation durations for each counter
      stats.slice(0, 3).forEach((stat, index) => {
        let start = 0;
        const end = stat.number;
        const duration = durations[index];
        const increment = end / (duration / 10);

        const interval = setInterval(() => {
          start += increment;
          if (start >= end) {
            start = end;
            clearInterval(interval);
          }
          setCounters((prev) => {
            const updatedCounters = [...prev];
            updatedCounters[index] = Math.round(start);
            return updatedCounters;
          });
        }, 10);
      });
    }
  }, [inView, stats]);

  return (
    <section className="py-5">
      <div className="container">
        {/* About Text Section */}
        <div className="mb-5">
          <h2 className="about-section-title">BUY BEST FURNITURE</h2>
          <div className="text-muted">
            <p>
              At SK_Furniture, we pride ourselves on offering high-quality,
              stylish furniture that transforms your home. Our brand is built on
              providing comfortable and durable pieces, from sofa sets to dining
              tables, study desks, and more. Each product is crafted with
              attention to detail, ensuring both functionality and design.
            </p>
            <p>
              We offer a wide range of furniture options, including
              multi-purpose items and the latest trends. Whether you're
              furnishing your living room, bedroom, or office, our collection
              has something for every need and style. Visit our online store or
              showrooms to explore our full range and find the perfect pieces to
              complete your home.
            </p>
          </div>
        </div>

        <div className="stats-container">
          {/* Stats Section */}
          <div ref={ref} className="stats-cards">
            {stats.map((stat, index) => (
              <div key={index} className="stat-card">
                <div className="stat-icon">{stat.icon}</div>
                <div className="stat-info">
                  <h3 className="stat-number">
                    {index < 3
                      ? index === 1
                        ? `${counters[index]}K+`
                        : `${counters[index]}+`
                      : stat.number}
                  </h3>
                  <div className="stat-text">
                    <div>{stat.title}</div>
                    <div>{stat.subtitle}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
