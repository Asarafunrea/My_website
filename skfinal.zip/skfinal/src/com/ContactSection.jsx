import React from "react";
import con from "../assets/about.png";

export default function ContactPage() {
  return (
    <div>
      {/* Hero Section */}
      <section
        style={{
          backgroundImage: `url(${con})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          padding: "60px 0",
        }}
        className="text-center text-white"
      >
        <h1 className="display-4 fw-bold">Contact Us</h1>
        <p className="lead">
          We'd love to hear from you. Reach out to us today!
        </p>
      </section>

      <div className="container my-5">
        <div className="row g-4">
          {/* Contact Form */}
          <div className="col-lg-6">
            <div className="card p-4 shadow-sm">
              <h2 className="h4 mb-4">Send us a Message</h2>
              <form>
                <div className="row mb-4">
                  <div className="col-sm-6">
                    <label htmlFor="name" className="form-label">
                      Name
                    </label>
                    <input
                      id="name"
                      type="text"
                      className="form-control"
                      placeholder="Your name"
                    />
                  </div>
                  <div className="col-sm-6">
                    <label htmlFor="email" className="form-label">
                      Email
                    </label>
                    <input
                      id="email"
                      type="email"
                      className="form-control"
                      placeholder="Your email"
                    />
                  </div>
                </div>

                <div className="mb-4">
                  <label htmlFor="subject" className="form-label">
                    Subject
                  </label>
                  <input
                    id="subject"
                    type="text"
                    className="form-control"
                    placeholder="Message subject"
                  />
                </div>

                <div className="mb-4">
                  <label htmlFor="message" className="form-label">
                    Message
                  </label>
                  <textarea
                    id="message"
                    className="form-control"
                    placeholder="Write your message here"
                    rows="4"
                  ></textarea>
                </div>

                <button type="submit" className="btn btn-warning w-100">
                  Send Message
                </button>
              </form>
            </div>
          </div>

          {/* Contact Information */}
          <div className="col-lg-6 mt-4 mt-lg-0">
            <div style={{ background: "#FFFAEA" }} className="p-4 rounded">
              <h3
                className="mb-4"
                style={{
                  fontSize: "1.5rem",
                  color: "#0E6B66",
                  fontWeight: 600,
                  marginBottom: "1rem",
                  lineHeight: 1.3,
                }}
              >
                <i className="fas fa-store"></i> Visit Our Showroom
              </h3>
              <p>
                Experience our furniture in person at our flagship showroom. Our
                expert staff will help you find the perfect pieces for your
                home.
              </p>
              <div className="mt-4">
                <h5
                  style={{
                    fontSize: "1.2rem",
                    color: "#0E6B66",
                    fontWeight: 600,
                  }}
                >
                  Showroom Hours:
                </h5>
                <p>Monday - Saturday: 10:00 AM - 8:00 PM</p>
                <p>Sunday: 11:00 AM - 6:00 PM</p>
              </div>

              <div className="w-0 mt-4">
                <iframe
                  title="Store Location"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3911.5445267865803!2d77.86582809120664!3d11.367941814862009!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba961fd4b4ab86b%3A0x20e9c6fbd85228a0!2sSri%20Krishna%20furniture!5e0!3m2!1sen!2sin!4v1732381877318!5m2!1sen!2sin"
                  width="100%"
                  height="300"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  className="rounded"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Customer Testimonials Section */}
        <div className="mt-5">
          <h4
            className="mb-4"
            style={{
              fontSize: "1.5rem",
              color: "#0E6B66",
              fontWeight: 600,
              marginBottom: "1rem",
              lineHeight: 1.3,
              textShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
            }}
          >
            Customer Reviews
          </h4>
          <div className="row">
            {/* Review 1 */}
            <div className="col-md-4">
              <div className="card p-3 shadow-sm">
                <p>
                  "Great service and fantastic furniture! Highly recommend!"
                </p>
                <div className="text-warning mb-2">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="far fa-star"></i>
                </div>
                <h6 className="text-end">- Arun</h6>
              </div>
            </div>

            {/* Review 2 */}
            <div className="col-md-4">
              <div className="card p-3 shadow-sm">
                <p>"The showroom is amazing, and the staff is very helpful!"</p>
                <div className="text-warning mb-2">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                </div>
                <h6 className="text-end">- Nithiya</h6>
              </div>
            </div>

            {/* Review 3 */}
            <div className="col-md-4">
              <div className="card p-3 shadow-sm">
                <p>"I found the perfect furniture for my home, thank you!"</p>
                <div className="text-warning mb-2">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="far fa-star"></i>
                </div>
                <h6 className="text-end">- Gowtham</h6>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
