import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom"; // Import for accessing location state
import ProductList from "./ProductList";
import ProductFilters from "./ProductFilters";
import { products } from "../data/products";

function ProductPage() {
  const location = useLocation();
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [selectedMaterials, setSelectedMaterials] = useState([]);
  const [priceRange, setPriceRange] = useState(30000);
  const [inStockOnly, setInStockOnly] = useState(false);

  useEffect(() => {
    if (location.state?.category) {
      setSelectedCategories([location.state.category]); // Set category from navigation state
    }
  }, [location.state]);

  const handleCategoryChange = (category) => {
    setSelectedCategories((prevCategories) =>
      prevCategories.includes(category)
        ? prevCategories.filter((item) => item !== category)
        : [...prevCategories, category]
    );
  };

  const handleMaterialChange = (material) => {
    setSelectedMaterials((prevMaterials) =>
      prevMaterials.includes(material)
        ? prevMaterials.filter((item) => item !== material)
        : [...prevMaterials, material]
    );
  };

  const handleClearFilters = () => {
    setSelectedCategories([]);
    setSelectedMaterials([]);
    setPriceRange(30000);
    setInStockOnly(false);
  };

  const filteredProducts = products.filter((product) => {
    return (
      (selectedCategories.length === 0 ||
        selectedCategories.includes(product.category)) &&
      (selectedMaterials.length === 0 ||
        selectedMaterials.includes(product.material)) &&
      product.price <= priceRange &&
      (!inStockOnly || product.inStock)
    );
  });

  return (
    <div className="container my-5">
      <div className="row">
        <div className="col-md-3">
          <ProductFilters
            selectedCategories={selectedCategories}
            selectedMaterials={selectedMaterials}
            priceRange={priceRange}
            inStockOnly={inStockOnly}
            onCategoryChange={handleCategoryChange}
            onMaterialChange={handleMaterialChange}
            onPriceRangeChange={setPriceRange}
            onInStockChange={setInStockOnly}
            onClearFilters={handleClearFilters}
          />
        </div>
        <div className="col-md-9">
          <ProductList products={filteredProducts} />
        </div>
      </div>
    </div>
  );
}

export default ProductPage;
