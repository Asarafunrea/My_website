import React from "react";
import {
  FaFacebookF,
  FaInstagram,
  FaYoutube,
  FaPhoneAlt,
  FaMailBulk,
  FaMapPin,
} from "react-icons/fa";
import { SiWhatsapp } from "react-icons/si";
import "../styles/footer.css";

const Footer = () => {
  return (
    <footer className="footer bg-black text-gray-200 py-12">
      <div className="container mx-auto px-4">
        <div className="footer-grid">
          {/* Company Info Section */}
          <div className="footer-section">
            <h2 className="footer-heading">Sri Krishna Furnitures</h2>
            <p className="footer-description">
              Discover the finest quality furniture with a focus on
              craftsmanship and comfort. Explore our wide range of furniture for
              your home and office.
            </p>
            <div className="social-icons">
              <a href="https://wa.me/916385894422" className="social-link">
                <SiWhatsapp size={24} />
              </a>
              <a href="#" className="social-link">
                <FaFacebookF size={24} />
              </a>
              <a href="#" className="social-link">
                <FaInstagram size={24} />
              </a>
              <a href="#" className="social-link">
                <FaYoutube size={24} />
              </a>
            </div>
          </div>

          {/* Contact Information */}
          <div className="footer-section">
            <h2 className="footer-heading">Contact Information</h2>
            <div className="contact-info">
              <div className="contact-item">
                <FaMapPin className="icon" size={20} />
                <p className="contact-text">
                  Sri Krishna Furnitures
                  <br />
                  58/1, Kootappalli Colony, Thiruchengode,
                  Manufacturing in Karapulimedu,
                  <br />
                  Keeleripatti, Thiruchengode, Namakkal.
                </p>
              </div>
              <div className="contact-item">
                <FaPhoneAlt className="icon" size={20} />
                <a href="tel:+916385894422" className="contact-text">
                  +91 63858 94422
                </a>
              </div>
              <div className="contact-item">
                <FaMailBulk className="icon" size={20} />
                <a
                  href="mailto:srikrishnafurnitures@gmail.com"
                  className="contact-text"
                >
                  srikrishnafurnitures@gmail.com
                </a>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="footer-section">
            <h2 className="footer-heading">Quick links</h2>
            <nav className="quick-links">
              <a href="/" className="quick-link">
                Home
              </a>
              <a href="/about" className="quick-link">
                About
              </a>
              <a href="/products" className="quick-link">
                Products
              </a>
              <a href="/contact" className="quick-link">
                Contact
              </a>
            </nav>
          </div>
        </div>

        {/* Copyright */}
        <div className="copyright">
          <p>
            &copy; {new Date().getFullYear()} Sri Krishna Furnitures. All rights
            reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
